package com.yash.damsapp.dao;

import com.yash.damsapp.domain.User;

public interface UserDAO {

	public void insert(User user);
}
