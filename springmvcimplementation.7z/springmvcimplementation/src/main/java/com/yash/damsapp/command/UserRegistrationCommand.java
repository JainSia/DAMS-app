package com.yash.damsapp.command;

public class UserRegistrationCommand {

}
