package com.yash.damsapp.controller;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.yash.damsapp.command.UserRegistrationCommand;
import com.yash.damsapp.domain.User;
import com.yash.damsapp.service.UserService;
import com.yash.damsapp.validator.UserRegistrationValidator;

/**
 * UserController is used to controls various activities related to user
 * @author saloni.jain
 *
 */
@Controller
@RequestMapping("/user")
@SessionAttributes("loginUser")
public class UserController {
	private static final Logger logger = Logger.getLogger(UserController.class);

	@Autowired
	private UserService userService;
	@Autowired
	private UserRegistrationValidator userRegistrationValidator;
	
	
		@InitBinder
		protected void initBinder(WebDataBinder binder) {
			binder.setValidator(userRegistrationValidator);
		}
	
	
	 @RequestMapping(value="/home", method=RequestMethod.GET)
	  public String showHomePage() {
 		return "home";
	  }
	 
	 @RequestMapping(value="/userRegistration", method=RequestMethod.GET)
	  public String showUserRegistration() {
		return "userRegistration";
	  }
 
	 @RequestMapping(value="/processUserRegistration", method=RequestMethod.POST)
	  public String processUserRegistration(@ModelAttribute("userForm") User user,BindingResult result ) {
		 userService.register(user);
		return "home";
	  }
	 
	 
	 @RequestMapping(value="/loginController", method=RequestMethod.POST)
	 public String loginUser(Model model,@ModelAttribute("command") User user,BindingResult result ,@RequestParam String loginname, @RequestParam String password) {
		
		 if(result.hasErrors()) {
			 return "userRegistration";
		 }
		 
		 
		User loginUser=userService.authenticateUser(loginname, password);
		 if(user!=null) {
			 model.addAttribute("loginUser",loginUser);
			 return "userDashboard";
		 }
		 model.addAttribute("message", "Invalid Loginname/password");
		 return "home";
	 }
	 
	 @RequestMapping(value="/logoutController", method=RequestMethod.POST)
	 public String loggedoutUser(HttpSession httpSession,SessionStatus status) {
		
		
		httpSession.invalidate();
		status.setComplete();
		return "home";
	 }
	

}
