package com.yash.damsapp.dao;

import com.yash.damsapp.domain.User;
import com.yash.damsapp.exception.DAOException;

public interface UserDAO {

	public int insert(User user) throws DAOException;
}
