package com.yash.damsapp.daoimpl;



import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.yash.damsapp.dao.UserDAO;
import com.yash.damsapp.domain.User;
import com.yash.damsapp.exception.DAOException;
@Repository
public class UserDAOImpl implements UserDAO {

	
	private static Logger logger=Logger.getLogger(UserDAOImpl.class);
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private DataSource dataSource;
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate=new JdbcTemplate(dataSource);
	}

	public int insert(User user) throws DAOException {

		int result = 0;
		try {
			String sql="insert into users(firstname,lastname,contact,email,address,loginname,password) values(?,?,?,?,?,?,?);";
			Object[] params=new Object[] {
				user.getFirstname(),
				user.getLastname(),
				user.getContact(),
				user.getEmail(),
				user.getAddress(),
				user.getLoginname(),
				user.getPassword(),
			};
			result=jdbcTemplate.update(sql,params);
		} catch (Exception e) {
			logger.error(e);
		}
		return result;
	}

	

	
	

}
