package com.yash.damsapp.exception;

public class DAOException extends Exception {
	
	private String message;

	@Override
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}
