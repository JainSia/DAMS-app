package com.yash.damsapp.exception;

public class ServiceException extends Exception {
	
	private String message;

	@Override
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}
