package com.yash.damsapp.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.yash.damsapp.domain.User;

public class UserRowMapper implements RowMapper{
	
	

	public User mapRow(ResultSet resultSet, int rowMapper) throws SQLException {
	
		User user=new User();
		user.setFirstname(resultSet.getString("firstname"));
		user.setLastname(resultSet.getString("lastname"));
		user.setContact(resultSet.getString("contact"));
		user.setEmail(resultSet.getString("email"));
		user.setAddress(resultSet.getString("address"));
		user.setLoginname(resultSet.getString("loginname"));
		user.setPassword(resultSet.getString("password"));
		return user;
	}

}
