package com.yash.damsapp.service;

import com.yash.damsapp.domain.User;

public interface UserService {
	
	public int register(User user) ;
	public User authenticateUser(String username,String password);
	
}
