package com.yash.damsapp.serviceimpl;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.yash.damsapp.dao.UserDAO;
import com.yash.damsapp.domain.User;
import com.yash.damsapp.rowmapper.UserRowMapper;
import com.yash.damsapp.service.UserService;
@Service
public class UserServiceImpl implements UserService{

	private static Logger logger=Logger.getLogger(UserServiceImpl.class);
	private JdbcTemplate jdbcTemplate;
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate=new JdbcTemplate(dataSource);
	}
	
	@Autowired
	private UserDAO userDAO;
	public int register(User user) {
		int result=0;
		try {
			result=userDAO.insert(user);
		} catch (Exception e) {
			logger.error(e);
		}
		return result;
	}
		
	@SuppressWarnings("unchecked")
	public User authenticateUser(String username,String password) {
	
		User user=null;
		Object[] params=new Object[] {
				username,
				password
		};
		String sql="select * from users where loginname=? AND password=?";
		user=jdbcTemplate.queryForObject(sql,params,new UserRowMapper());
		return user;
	}

}
