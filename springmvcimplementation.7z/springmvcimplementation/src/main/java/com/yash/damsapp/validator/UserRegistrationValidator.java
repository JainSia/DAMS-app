package com.yash.damsapp.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

public class UserRegistrationValidator implements Validator {

	public boolean supports(Class<?> arg0) {
		
		return false;
	}

	public void validate(Object arg0, Errors arg1) {
		
		
	}
	
	

}
